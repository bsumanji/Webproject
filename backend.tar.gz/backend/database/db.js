module.exports = {
db: 'mongodb://web-mongodb:27017/reactdb'
};

